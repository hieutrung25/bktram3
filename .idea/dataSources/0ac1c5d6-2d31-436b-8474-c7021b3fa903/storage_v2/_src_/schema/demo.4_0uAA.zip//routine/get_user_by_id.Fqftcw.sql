create
    definer = root@localhost procedure get_user_by_id(IN user_id int)
begin
select name, email, country
from users
where id = user_id;
end;

